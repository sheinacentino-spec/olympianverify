# OlympianVerify

A Pen created on CodePen.

Original URL: [https://codepen.io/y-she/pen/PwZegqW](https://codepen.io/y-she/pen/PwZegqW).

